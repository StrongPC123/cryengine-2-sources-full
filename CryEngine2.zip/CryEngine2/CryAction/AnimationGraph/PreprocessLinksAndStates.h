#ifndef __PREPROCESSLINKSANDSTATES_H__
#define __PREPROCESSLINKSANDSTATES_H__

#pragma once

bool PreprocessLinksAndStates( XmlNodeRef root );

#endif
