#include "StateIndex.h"

STRUCT_INFO_BEGIN(CStateIndex::StateID)
	STRUCT_VAR_INFO(_value, TYPE_INFO(uint16))
STRUCT_INFO_END(CStateIndex::StateID)

